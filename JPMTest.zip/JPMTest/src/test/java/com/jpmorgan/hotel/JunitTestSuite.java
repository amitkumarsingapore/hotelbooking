package com.jpmorgan.hotel;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.jpmorgan.hotel.helper.LoggerService;


/**
 * This is Junit Test Suite combining all test cases.
 * 
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */

@RunWith(Suite.class)
//Test class names
@Suite.SuiteClasses({
	
	//Test classes to be added in suite
	com.jpmorgan.hotel.master.StandardRoomTest.class,
	com.jpmorgan.hotel.master.SuiteRoomTest.class,
	com.jpmorgan.hotel.master.GreatViewRoomTest.class,
	com.jpmorgan.hotel.master.RoomBookingServiceTest.class
})
public class JunitTestSuite {  
	//To display log information for testing
	static {
	final Logger logger = LoggerService
	.getLogger(JunitTestSuite.class);

	logger.log(Level.INFO, "Testing " + JunitTestSuite.class.getName());
	}
	
}  