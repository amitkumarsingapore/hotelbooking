
package com.jpmorgan.hotel.master;

import static org.junit.Assert.assertEquals;

import java.util.ResourceBundle;

import org.junit.Before;
import org.junit.Test;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.PriceMaster;
import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.helper.HelperService;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public class SuiteRoomTest {

	SuiteRoom suite;
	PriceMaster priceMaster=null;

	/**
	 * Resource Bundle to use for all messages and error messages maintained in
	 * resource file(/resources/message.properties)
	 */
	protected ResourceBundle resource = HelperService
			.getResourceBundle(Config.MessageResourceBundle);
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		priceMaster= new PriceMaster();
	}


	/**
	 * Test method for {@link com.jpmorgan.hotel.master.SuiteRoom#SuiteRoom(java.lang.String)}.
	 */
	@Test
	public void testSuiteRoom() {
		String id="Room1";
		suite= new SuiteRoom(id);
		assertEquals(suite.getId(), id);
		
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.SuiteRoom#getId()}.
	 */
	@Test
	public void testGetId() {
		String id="Room1";
		suite= new SuiteRoom(id);
		id="Room2";
		suite= new SuiteRoom(id);
		assertEquals(suite.getId(), id);
		
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.SuiteRoom#calculate(Facilities[])}.
	 * @throws BookingException 
	 */
	@Test
	public void testCalculate() throws BookingException {
		String id="Room1";
		double price=0.0;
		double expectedPrice = 0;
		suite= new SuiteRoom(id);
		
		
		//TEST SINGLE FACULITY PRICES
		for (Facilities facility : Facilities.values()) {
			price=suite.calculate(facility);
			expectedPrice = new Double(priceMaster.FacilitiesPrice.get(facility)).doubleValue();
			
			assertEquals(price, expectedPrice, 0);
		}
		
		//Test No Facility
		price=suite.calculate(Facilities.NO_FACILITY);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		//case2 withour argument
		price=suite.calculate();
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		//test for mix case
		price=suite.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		
		//test for repeat case. It should be same as previous
		price=suite.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,
				Facilities.ENSUITE_BATHROOM);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		
		//tets for all facilities
		price=suite.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,
				Facilities.INTERNET,
				Facilities.LATE_CHECKOUT,
				Facilities.SWIMMINGPOOL);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.INTERNET)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.LATE_CHECKOUT)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.SWIMMINGPOOL)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
	 	
		
		
	}

}
