
package com.jpmorgan.hotel.master;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.PriceMaster;
import com.jpmorgan.hotel.exception.BookingException;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public class GreatViewRoomTest {

	GreatViewRoom gvr;
	PriceMaster priceMaster=null;


	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		priceMaster= new PriceMaster();
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.GreatViewRoom#calculate(com.jpmorgan.hotel.core.Facilities[])}.
	 * @throws BookingException 
	 */
	@Test
	public void testCalculate() throws BookingException {
		String id="Room1";
		double price=0.0;
		double expectedPrice=0.0;
		gvr= new GreatViewRoom(id);
		
		
		//TEST SINGLE FACULITY PRICES
		for (Facilities facility : Facilities.values()) {
			price=gvr.calculate(facility);
			expectedPrice = 2 * new Double(priceMaster.FacilitiesPrice.get(facility)).doubleValue();
			assertEquals(price, expectedPrice, 0);
		}
		
		//Test No Facility
		price=gvr.calculate(Facilities.NO_FACILITY);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		//case2 withour argument
		price=gvr.calculate();
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
		//Test for mix case
		price=gvr.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice =expectedPrice*2;
		assertEquals(price, expectedPrice, 0);
		
		//Tets for repeat case
		price=gvr.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST
				,Facilities.ENSUITE_BATHROOM);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice =expectedPrice*2;
		
		
		//tets for all facilities
		price=gvr.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,
				Facilities.INTERNET,
				Facilities.LATE_CHECKOUT,
				Facilities.SWIMMINGPOOL);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.INTERNET)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.LATE_CHECKOUT)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.SWIMMINGPOOL)).doubleValue();
		expectedPrice =expectedPrice*2;
		assertEquals(price, expectedPrice, 0);
		
	 	
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.GreatViewRoom#GreatViewRoom(java.lang.String)}.
	 */
	@Test
	public void testGreatViewRoom() {
		String id="Room1";
		gvr= new GreatViewRoom(id);
		assertEquals(gvr.getId(), id);

	}

}
