package com.jpmorgan.hotel.master;

import static org.junit.Assert.*;

import java.util.Collection;

import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.config.Message;
import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.PriceMaster;
import com.jpmorgan.hotel.core.RoomType;
import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.helper.HelperService;
import com.jpmorgan.hotel.helper.LoggerService;

/**
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public class RoomBookingServiceTest {

	RoomBookingService booking;
	PriceMaster priceMaster = null;
	final int SUITE_ROOMS = 30;
	final int GVR_ROOMS = 30;
	final int STR_ROOMS = 30;
	
	/**
	 * Resource Bundle to use for all messages and error messages maintained in
	 * resource file(/resources/message.properties)
	 */
	protected ResourceBundle resource = HelperService
			.getResourceBundle(Config.MessageResourceBundle);
	
	Logger logger = LoggerService.getLogger(RoomBookingService.class);

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		booking = new RoomBookingService();
		priceMaster = new PriceMaster();
	}

	/**
	 * Test method for
	 * {@link com.jpmorgan.hotel.master.RoomBookingService#addSuiteRoom(com.jpmorgan.hotel.master.SuiteRoom)}
	 * .
	 */
	@Test
	public void testAddSuiteRoom() {
		// No room a sof now
		assertTrue(booking.getAvailableRooms().size() == 0);

		// Add 30 rooms
		for (int i = 0; i < SUITE_ROOMS; i++) {
			booking.addSuiteRoom(new SuiteRoom(RoomType.SUITE.toString() + i));
		}

		assertTrue(booking.getAvailableRooms().size() == SUITE_ROOMS);

	}

	/**
	 * Test method for
	 * {@link com.jpmorgan.hotel.master.RoomBookingService#quoteRoom(java.lang.String, java.lang.String[])}
	 * .
	 * 
	 * @throws BookingException
	 */
	@Test
	public void testQuoteRoom() throws BookingException {
		
		testQuoteSuiteRoom();
		testQuoteGVRRoom();
		testQuoteSTRRoom();
		
	 	
	}

	/**
	 * @throws BookingException 
	 * 
	 */
	private void testQuoteSuiteRoom() throws BookingException {
		double price = 0;
		double expectedPrice = 0;
	
		// Add 30 rooms
		for (int i = 0; i < SUITE_ROOMS; i++) {
			booking.addSuiteRoom(new SuiteRoom(RoomType.SUITE.toString() + i));
		}
		// TEST SINGLE Facility FOR SUITE ROOMS
		int suiteRoom = 1;
		for (Facilities facility : Facilities.values()) {
			if (suiteRoom > SUITE_ROOMS)
				break;

			price = booking.quoteRoom(
					RoomType.SUITE.toString() + (suiteRoom++),
					facility.toString());
			expectedPrice = new Double(
					priceMaster.FacilitiesPrice.get(facility)).doubleValue();
			if (facility.equals(Facilities.NO_FACILITY))
				continue;

			assertEquals(price, expectedPrice, 0);
		}

		// TEST TWO Facility FOR SUITE ROOMS
		price = booking.quoteRoom(RoomType.SUITE.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString());
		expectedPrice = new Double(
				priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM))
		.doubleValue();
		expectedPrice += new Double(
				priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST))
		.doubleValue();
		assertEquals(price, expectedPrice, 0);

		// TEST ALL Facilities  FOR SUITE ROOMS
		
		//tets for all facilities
		price=booking.quoteRoom(RoomType.SUITE.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString(),
				Facilities.INTERNET.toString(),
				Facilities.LATE_CHECKOUT.toString(),
				Facilities.SWIMMINGPOOL.toString());
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.INTERNET)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.LATE_CHECKOUT)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.SWIMMINGPOOL)).doubleValue();
		assertEquals(price, expectedPrice, 0);
		
	}

	
	/**
	 * @throws BookingException 
	 * 
	 */
	private void testQuoteGVRRoom() throws BookingException {
		double price = 0;
		double expectedPrice = 0;
	
		// Add 30 rooms
		for (int i = 0; i < GVR_ROOMS; i++) {
			booking.addGreatViewRoom(new GreatViewRoom(RoomType.GREATVIEW.toString() + i));
		}
		// TEST SINGLE Facility FOR GVR ROOMS
		int suiteRoom = 1;
		for (Facilities facility : Facilities.values()) {
			if (suiteRoom > GVR_ROOMS)
				break;

			price = booking.quoteRoom(
					RoomType.GREATVIEW.toString() + (suiteRoom++),
					facility.toString());
			expectedPrice = new Double(
					priceMaster.FacilitiesPrice.get(facility)).doubleValue();
			expectedPrice=2*expectedPrice;
			logger.log(Level.INFO,expectedPrice+"--"+facility+"--"+price);
			if (facility.equals(Facilities.NO_FACILITY))
				continue;

			assertEquals(price, expectedPrice, 0);
		}

		// TEST TWO Facility FOR GVR ROOMS
		price = booking.quoteRoom(RoomType.GREATVIEW.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString());
		expectedPrice = new Double(
				priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM))
		.doubleValue();
		expectedPrice += new Double(
				priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST))
		.doubleValue();
		expectedPrice=2*expectedPrice;
		assertEquals(price, expectedPrice, 0);

		// TEST ALL Facilities  FOR GVR ROOMS
		
		//tets for all facilities
		price=booking.quoteRoom(RoomType.GREATVIEW.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString(),
				Facilities.INTERNET.toString(),
				Facilities.LATE_CHECKOUT.toString(),
				Facilities.SWIMMINGPOOL.toString());
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.ENSUITE_BATHROOM)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.ROOM_BREAKFAST)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.INTERNET)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.LATE_CHECKOUT)).doubleValue();
		expectedPrice += new Double(priceMaster.FacilitiesPrice.get(Facilities.SWIMMINGPOOL)).doubleValue();
		expectedPrice=2*expectedPrice;
		assertEquals(price, expectedPrice, 0);
		
	}
	
	/**
	 * @throws BookingException 
	 * 
	 */
	private void testQuoteSTRRoom() throws BookingException {
		double price = 0;
		double expectedPrice = 0;
	
		// Add 30 rooms
		for (int i = 0; i < STR_ROOMS; i++) {
			booking.addStandardRoom(new StandardRoom(RoomType.STANDARD.toString() + i));
		}
		
		// TEST SINGLE Facility FOR STANDARD ROOMS
		int suiteRoom = 1;
		for (Facilities facility : Facilities.values()) {
			if (suiteRoom > STR_ROOMS)
				break;

			price = booking.quoteRoom(
					RoomType.STANDARD.toString() + (suiteRoom++),
					facility.toString());
			expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
			logger.log(Level.INFO,expectedPrice+"--"+facility+"--"+price);
		if (facility.equals(Facilities.NO_FACILITY))
				continue;

			assertEquals(price, expectedPrice, 0);
		}

		// TEST TWO Facility FOR STANDARD ROOMS
		price = booking.quoteRoom(RoomType.STANDARD.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString());
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
		// TEST ALL Facilities  FOR SUITE ROOMS
		
		//tets for all facilities
		price=booking.quoteRoom(RoomType.STANDARD.toString() + (suiteRoom++),
				Facilities.ENSUITE_BATHROOM.toString(),
				Facilities.ROOM_BREAKFAST.toString(),
				Facilities.INTERNET.toString(),
				Facilities.LATE_CHECKOUT.toString(),
				Facilities.SWIMMINGPOOL.toString());
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
	}
	
	/**
	 * Test method for
	 * {@link com.jpmorgan.hotel.master.RoomBookingService#getAvailableRooms()}.
	 */
	@Test
	public void testGetAvailableRooms() {
		Collection<?> rooms=booking.getAvailableRooms();
		assertNotNull(rooms);
		assertTrue(rooms.size()==0);
		
		//Add some rooms
		// Add 30 rooms
		for (int i = 0; i < STR_ROOMS; i++) {
			booking.addStandardRoom(new StandardRoom(RoomType.STANDARD.toString() + i));
		}
		assertTrue(rooms.size()==30);
		
	}

	/**
	 * Test method for
	 * {@link com.jpmorgan.hotel.master.RoomBookingService#addGreatViewRoom(com.jpmorgan.hotel.master.GreatViewRoom)}
	 * .
	 */
	@Test
	public void testAddGreatViewRoom() {
		// No room a sof now
		assertTrue(booking.getAvailableRooms().size() == 0);

		// Add 30 rooms
		for (int i = 0; i < GVR_ROOMS; i++) {
			booking.addSuiteRoom(new GreatViewRoom(RoomType.GREATVIEW.toString() + i));
		}

		assertTrue(booking.getAvailableRooms().size() == GVR_ROOMS);

	
		
	}

	/**
	 * Test method for
	 * {@link com.jpmorgan.hotel.master.RoomBookingService#addStandardRoom(com.jpmorgan.hotel.master.StandardRoom)}
	 * .
	 */
	@Test
	public void testAddStandardRoom() {
		// No room a sof now
		assertTrue(booking.getAvailableRooms().size() == 0);

		// Add 30 rooms
		for (int i = 0; i < STR_ROOMS; i++) {
			booking.addSuiteRoom(new GreatViewRoom(RoomType.STANDARD.toString() + i));
		}

		assertTrue(booking.getAvailableRooms().size() == STR_ROOMS);

	
	}

}
