
package com.jpmorgan.hotel.master;

import static org.junit.Assert.*;

import java.util.ResourceBundle;

import org.junit.Before;
import org.junit.Test;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.config.Message;
import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.PriceMaster;
import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.helper.HelperService;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public class StandardRoomTest {

	StandardRoom str;
	PriceMaster priceMaster=null;
	

	/**
	 * Resource Bundle to use for all messages and error messages maintained in
	 * resource file(/resources/message.properties)
	 */
	protected ResourceBundle resource = HelperService
			.getResourceBundle(Config.MessageResourceBundle);
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		priceMaster= new PriceMaster();
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.StandardRoom#calculate(com.jpmorgan.hotel.core.Facilities[])}.
	 * @throws BookingException 
	 */
	@Test
	public void testCalculate() throws BookingException {
		String id="Room1";
		double price=0.0;
		double expectedPrice = 0.0;
		str= new StandardRoom(id);
		
		
		//TEST SINGLE FACULITY PRICES
		for (Facilities facility : Facilities.values()) {
			if(facility.equals(Facilities.NO_FACILITY)) continue;
			price=str.calculate(facility);
			expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
			
			assertEquals(price, expectedPrice, 0);
		}
		
		//Test No Facility
		price=str.calculate(Facilities.NO_FACILITY);
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
	
		//test for default.. blank one (no facilities)
		price=str.calculate();
		expectedPrice = new Double(priceMaster.FacilitiesPrice.get(Facilities.NO_FACILITY)).doubleValue();
		assertEquals(price, expectedPrice, 0);
	
		//Test 2 facility
		price=str.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST);
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
	
		//Test 3 facility
		price=str.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,Facilities.SWIMMINGPOOL);
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
	
		//Test 4 facility
		price=str.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,Facilities.SWIMMINGPOOL
				, Facilities.LATE_CHECKOUT);
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
		//Test 5 facility
		price=str.calculate(Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,Facilities.SWIMMINGPOOL
				, Facilities.LATE_CHECKOUT, Facilities.INTERNET);
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
		//Test for reapted facilities
		price=str.calculate(Facilities.LATE_CHECKOUT,
				Facilities.ENSUITE_BATHROOM
				, Facilities.ROOM_BREAKFAST,Facilities.SWIMMINGPOOL
				, Facilities.LATE_CHECKOUT, Facilities.INTERNET
				, Facilities.LATE_CHECKOUT);
		expectedPrice = new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_MID_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		expectedPrice += new Double(resource.getString(Message.STANDARD_FULL_PRICE.toString()));
		assertEquals(price, expectedPrice, 0);
		
		
	
	}

	/**
	 * Test method for {@link com.jpmorgan.hotel.master.StandardRoom#StandardRoom(java.lang.String)}.
	 */
	@Test
	public void testStandardRoom() {
		String id="Room1";
		str= new StandardRoom(id);
		assertEquals(str.getId(), id);

	}

}
