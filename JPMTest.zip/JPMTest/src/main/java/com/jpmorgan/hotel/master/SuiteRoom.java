package com.jpmorgan.hotel.master;

import com.jpmorgan.hotel.core.Facilities;

import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.interfaces.AbstractRoom;

/**
 * This class represent suite rooms
 * 
 * SuiteRoom
 */
public class SuiteRoom extends AbstractRoom {

	/**
	 * Create Suite Room
	 * 
	 * @param id
	 *            : Room ID
	 */
	public SuiteRoom(String id) {
		super(id);
	}

	/**
	 * This method calculate prices for suite room based on configured price
	 * list
	 * 
	 * @param facilities
	 * @return
	 * @throws BookingException
	 */
	public double calculate(Facilities... facilities) throws BookingException {
		double price = 0;

		facilities = validate(facilities);

		for (Facilities facility : facilities) {
			price += priceMaster.FacilitiesPrice.get(facility);
		}
		return price;
	}
}
