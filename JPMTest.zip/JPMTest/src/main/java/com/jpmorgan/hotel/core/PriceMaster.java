
package com.jpmorgan.hotel.core;

import java.util.HashMap;
import java.util.ResourceBundle;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.config.Message;
import com.jpmorgan.hotel.helper.HelperService;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public class PriceMaster {
	
	/**
	 * Resource Bundle to use for all messages and error messages maintained in
	 * resource file(/resources/message.properties)
	 */
	protected ResourceBundle resource = HelperService
			.getResourceBundle(Config.MessageResourceBundle);
	
   public final HashMap<Facilities, Double> FacilitiesPrice=
	   new  HashMap<Facilities, Double>(){
	   /**
		 * 
		 */
		private static final long serialVersionUID = -6015524138510182358L;

	   {
		   
		   put(Facilities.ENSUITE_BATHROOM,
			Double.parseDouble(
		    		resource.getString(Message.PRICE_ENSUITE_BATHROOM.toString()) 
		    	)
		    );
		   put(Facilities.ROOM_BREAKFAST,
					Double.parseDouble(
				    		resource.getString(Message.PRICE_ROOM_BREAKFAST.toString()) 
				    	)
				    );
		   put(Facilities.INTERNET,
					Double.parseDouble(
				    		resource.getString(Message.PRICE_INTERNET.toString()) 
				    	)
				    );
		   put(Facilities.LATE_CHECKOUT,
					Double.parseDouble(
				    		resource.getString(Message.PRICE_LATE_CHECKOUT.toString()) 
				    	)
				    );
		   put(Facilities.SWIMMINGPOOL,
					Double.parseDouble(
				    		resource.getString(Message.PRICE_SWIMMINGPOOL.toString()) 
				    	)
				    );
		   
		   put(Facilities.NO_FACILITY,
					Double.parseDouble(
				    		resource.getString(Message.PRICE_NO_FACILITY.toString()) 
				    	)
				    );	 
		  
	   }
   };
  
}
