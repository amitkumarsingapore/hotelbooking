package com.jpmorgan.hotel.util;

import java.util.ArrayList;

import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.RoomType;

/**
 * This is utility class to provide generic/common methods.
 * 
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public class UtilityService {

	/**
	 * @param facilities
	 * @return
	 */
	public static Facilities[] getUnique(Facilities[] facilities) {
		ArrayList<Facilities> uniqueFacilities=new ArrayList<Facilities>();
		
		for (Facilities facility : facilities) {
			if( !uniqueFacilities.contains(facility))
					uniqueFacilities.add(facility);	
		}
		
		Facilities[] newlist= new Facilities[uniqueFacilities.size()];
		uniqueFacilities.toArray(newlist);
		
		return newlist;
	}

	/**
	 * @param facilities
	 * @param noFacility
	 * @return
	 */
	public static Facilities[] filter(Facilities[] facilities,
			Facilities noFacility) {
		ArrayList<Facilities> uniqueFacilities=new ArrayList<Facilities>();
			
			for (Facilities facility : facilities) {
				if( facility.equals(noFacility))
					continue;
				else uniqueFacilities.add(facility);	
			}
			
			Facilities[] newlist= new Facilities[uniqueFacilities.size()];
			uniqueFacilities.toArray(newlist);
			
			return newlist;	
			
	}

	/**
	 * @param id
	 * @return
	 */
	public static RoomType wrapRoomType(String id) {
		for (RoomType room : RoomType.values()) {
			if( room.equals(id))
				return room;
		}
		
		return null;
	}
}
