
package com.jpmorgan.hotel.core;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public enum Facilities {
  SWIMMINGPOOL,
  ENSUITE_BATHROOM,
  ROOM_BREAKFAST,
  INTERNET,
  LATE_CHECKOUT,
  NO_FACILITY;
}
