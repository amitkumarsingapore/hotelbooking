package com.jpmorgan.hotel.master;

import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.exception.BookingException;

/**
 * This class extends faeture of suiterom to duble the prices
 */
public class GreatViewRoom extends SuiteRoom {

	/**
	 * Create GVR Room
	 * 
	 * @param id
	 *            : Room ID
	 */
	public GreatViewRoom(String id) {
		super(id);
	}

	/**
	 * This method calculate prices for suite room based on configured price
	 * list
	 * 
	 * @param facilities
	 * @return
	 * @throws BookingException
	 */
	@Override
	public double calculate(Facilities... facilities) throws BookingException {
		return 2 * super.calculate(facilities);
	}
}
