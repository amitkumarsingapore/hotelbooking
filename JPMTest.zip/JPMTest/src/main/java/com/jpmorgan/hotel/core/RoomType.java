
package com.jpmorgan.hotel.core;

/**
 * @author : amitkumarsingapore@gmail.com
 * Date: Feb 3, 2015
 */
public enum RoomType {
  STANDARD,
  SUITE,
  GREATVIEW
}
