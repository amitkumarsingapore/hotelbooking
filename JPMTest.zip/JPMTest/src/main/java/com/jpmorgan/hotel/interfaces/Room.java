package com.jpmorgan.hotel.interfaces;

import com.jpmorgan.hotel.exception.BookingException;

/**
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public interface Room {
	/**
	 * This method provide genric behaviour for price calculations.
	 * 
	 * @param facilities
	 *            : To be used for price calculations
	 * @return : Price based on individual room based calculations
	 * @throws BookingException
	 *             : Throws if failure during room booking or price calculations
	 */
	public double calculatePrice(String... facilities) throws BookingException;

}
