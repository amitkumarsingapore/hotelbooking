package com.jpmorgan.hotel.config;

import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jpmorgan.hotel.exception.BookingInitilizationError;
import com.jpmorgan.hotel.exception.BookingInitilizationException;
import com.jpmorgan.hotel.helper.LoggerService;

/**
 * This Class is Interface for configuration
 * 
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public class Config {

	private static final Logger logger = LoggerService.getLogger(Config.class);

	/**
	 * To ensure that all configuration loaded exactly once
	 */
	static boolean configLoaded = false;

	/**
	 * Various resource bundle properties
	 */
	public static String MessageResourceBundle; // ResourceBundle

	/**
	 * This method initialise all the configuration parameter by reader from
	 * property file config.properties.
	 * 
	 * @throws BookingInitilizationException
	 */
	public static void init() {

		// No action needed if configuration is already loaded.
		if (configLoaded)
			return;

		try {

			ResourceBundle rb = ResourceBundle.getBundle("configuration");

			MessageResourceBundle = rb.getString("MessageResourceBundle");
			configLoaded = true;

		} catch (Exception exception) {
			String errorMessage = exception.getMessage();
			logger.log(Level.SEVERE, errorMessage);
			// Throw Runtime error (Unchecked Exception)
			throw new BookingInitilizationError(errorMessage, exception);

		}

	}

}
