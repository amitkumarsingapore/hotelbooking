package com.jpmorgan.hotel.interfaces;

import java.util.ResourceBundle;
import java.util.logging.Logger;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.config.Message;
import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.core.PriceMaster;
import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.helper.HelperService;
import com.jpmorgan.hotel.helper.LoggerService;
import com.jpmorgan.hotel.util.UtilityService;

/**
 * This class provide framework for price calculation and provide custom
 * calculation to be patched via its implemented class.
 * 
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public abstract class AbstractRoom implements Room {
	// Room Id
	String id;

	public AbstractRoom() {
		// Initilize run time param
		initilize();
	}

	public AbstractRoom(String id) {
		// Initilize run time param
		this.id = id;
		initilize();

	}

	/**
	 * Getter method
	 * 
	 * @return Room ID for Each type of rooms
	 */
	public String getId() {
		return id;
	}

	/**
	 * Resource Bundle to use for all messages and error messages maintained in
	 * resource file(/resources/message.properties)
	 */
	protected ResourceBundle resource = HelperService
			.getResourceBundle(Config.MessageResourceBundle);
	Logger logger = LoggerService.getLogger(AbstractRoom.class);

	protected PriceMaster priceMaster = null;

	private void initilize() {
		priceMaster = new PriceMaster();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jpmorgan.hotel.core.Room#calculatePrice(java.lang.String[])
	 */
	@Override
	public double calculatePrice(String... facilities) throws BookingException {
		double price = 0.0;
		try {
			// Warp the facilities to structured
			Facilities[] facilitiesList = wrapFacilities(facilities);

			// validate inputs
			facilitiesList = validate(facilitiesList);

			price = calculate(facilitiesList);

		} catch (Exception exception) {
			String errorMessage = resource.getString(Message.GENERIC_FAILURE
					.toString()) + exception.getMessage();
			throw new BookingException(errorMessage, exception);
		}

		return price;
	};

	/**
	 * This method must be overridden by subclass to calculate prices
	 * 
	 * @param facilities
	 *            :Facilities to be validated
	 * @return : Calculated price for specific room type
	 * @throws BookingException
	 *             : If failed to perform price calculation
	 */
	protected abstract double calculate(Facilities... facilities)
			throws BookingException;

	/**
	 * This is framework method to validate input facilities
	 * 
	 * @param facilities
	 *            :Facilities to be validated
	 * @return: Structured Facilties list after validation
	 * @throws BookingException
	 *             : If failed to perform validation failure
	 */
	protected Facilities[] validate(Facilities... facilities)
			throws BookingException {
		Facilities[] maskedFacilities = null;
		// Check iF no facility provided
		if (facilities == null || facilities.length == 0)
			maskedFacilities = new Facilities[] { Facilities.NO_FACILITY };
		else
			maskedFacilities = facilities;

		// Check unique facilities
		maskedFacilities = UtilityService.getUnique(facilities);

		return maskedFacilities;
	}

	/**
	 * This method converts faclities to Structured format and do validations
	 * over that.
	 * 
	 * @param facilitiesStr
	 *            : Facilities to be wrapped
	 * @return: Structured Facilties list after validation
	 * @throws BookingException
	 *             : If failed to perform Wrapping or validation failure
	 */
	protected Facilities[] wrapFacilities(String... facilitiesStr)
			throws BookingException {
		Facilities[] facilities = new Facilities[facilitiesStr.length];
		int wrapped = 0;
		for (String facilityStr : facilitiesStr) {
			for (Facilities facility : Facilities.values()) {
				if (facility.toString().equals(facilityStr)) {
					facilities[wrapped++] = facility;
					break;
				}
			}
		}

		// In case any input is incorrect.
		if (wrapped != facilitiesStr.length) {
			String errorMessage = resource.getString(Message.INPUT_FAILURE
					.toString());

			throw new BookingException(errorMessage);
		}

		return facilities;
	}
}
