package com.jpmorgan.hotel.config;

/**
 * This is Interface for managing messages.
 * 
 * @link Please refer resource file /src/main/resources/message_en_US.properties.
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public enum Message {
	
	/**
	 * All these messages are Key-value pairs that works as bridge between
	 * actual Caller program and Resource Bundle.
	 */
	GENERIC_FAILURE,
	INPUT_FAILURE,
	PRICE_ENSUITE_BATHROOM,
	PRICE_ROOM_BREAKFAST, 
	PRICE_INTERNET, 
	PRICE_LATE_CHECKOUT, 
	PRICE_SWIMMINGPOOL,
	PRICE_NO_FACILITY,
	STANDARD_MID_PRICE,
	STANDARD_FULL_PRICE
	}
