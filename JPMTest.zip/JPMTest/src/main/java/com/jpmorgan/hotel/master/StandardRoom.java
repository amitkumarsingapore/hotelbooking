package com.jpmorgan.hotel.master;

import com.jpmorgan.hotel.config.Message;
import com.jpmorgan.hotel.core.Facilities;
import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.interfaces.AbstractRoom;
import com.jpmorgan.hotel.util.UtilityService;

/**
 * This class represents standard room.
 * 
 * StandardRoom
 */
public class StandardRoom extends AbstractRoom {
	/**
	 * Create standard Room
	 * 
	 * @param id: Room ID
	 */
	public StandardRoom(String id) {
		super(id);
	}

	/**
	 * This method calculate prices for suite room based on configured price
	 * list
	 * 
	 * @param facilities
	 * @return
	 * @throws BookingException
	 */
	public double calculate(Facilities... facilities) throws BookingException {
		double price = 0;

		facilities = validate(facilities);
		facilities = UtilityService.filter(facilities, Facilities.NO_FACILITY);

		if (facilities.length > 3) {
			price = 3
			* new Double(resource.getString(Message.STANDARD_MID_PRICE
					.toString()))
			+ (facilities.length - 3)
			* new Double(resource.getString(Message.STANDARD_FULL_PRICE
					.toString()));
		} else {
			price = facilities.length
			* new Double(resource.getString(Message.STANDARD_MID_PRICE
					.toString()));
		}

		return price;
	}
}
