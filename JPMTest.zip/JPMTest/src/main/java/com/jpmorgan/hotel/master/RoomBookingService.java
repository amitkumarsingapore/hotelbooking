package com.jpmorgan.hotel.master;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jpmorgan.hotel.exception.BookingException;
import com.jpmorgan.hotel.helper.LoggerService;

/**
 * This class handle the room booking and status checks.
 * 
 * SRBS
 */
public class RoomBookingService {
	/**
	 * availableRooms
	 */
	private HashMap<String, Object> availableRooms = new HashMap<String, Object>();

	Logger logger = LoggerService.getLogger(RoomBookingService.class);

	/**
	 * 
	 * @param id
	 * @param facilities
	 * @return
	 * @throws BookingException
	 */
	public double quoteRoom(String roomid, String... facilities)
			throws BookingException {
		double price = 0.0;
		Object room = availableRooms.get(roomid);
		availableRooms.remove(roomid);

		logger.log(Level.INFO,
				"Available Rooms at " + new Date(System.currentTimeMillis())
						+ " : " + availableRooms);

		if (room instanceof GreatViewRoom) {
			price = ((GreatViewRoom) room).calculatePrice(facilities);
		} else if (room instanceof StandardRoom) {
			price = ((StandardRoom) room).calculatePrice(facilities);
		} else if (room instanceof SuiteRoom) {
			price = ((SuiteRoom) room).calculatePrice(facilities);
		}

		logger.log(Level.INFO,
				" Quation at " + new Date(System.currentTimeMillis()) + " : "
						+ price);

		return price;
	}

	/**
	 * 
	 * @return
	 */
	public Collection<?> getAvailableRooms() {
		return availableRooms.values();
	}

	/**
	 * 
	 * @param room
	 */
	public void addGreatViewRoom(GreatViewRoom room) {
		availableRooms.put(room.getId(), room);
	}

	/**
	 * 
	 * @param room
	 */
	public void addStandardRoom(StandardRoom room) {
		availableRooms.put(room.getId(), room);
	}

	/**
	 * 
	 * @param room
	 */
	public void addSuiteRoom(SuiteRoom room) {
		availableRooms.put(room.getId(), room);
	}

}
