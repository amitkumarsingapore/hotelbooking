package com.jpmorgan.hotel.helper;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.jpmorgan.hotel.config.Config;
import com.jpmorgan.hotel.exception.BookingInitilizationError;


/**
 * This is Helper class to support generic method shared across the project
 * 
 * @author : amitkumarsingapore@gmail.com Date: Feb 3, 2015
 */
public class HelperService {

	private static final Logger logger = LoggerService
			.getLogger(HelperService.class);
	/**
	 * This method loads the resource Bundle to fetch the messages and labels
	 * from message.properties file.
	 * 
	 * @param propertyfile
	 *            : File to be loaded and processed
	 * @return All properties loaded as Resource Bundle
	 */
	public static ResourceBundle getResourceBundle(String propertyfile) {
		ResourceBundle bundle;
		try {
			// Check if Configuration file already loaded. Load it if it is not
			// already loaded.
			if(propertyfile==null){
				Config.init();
				propertyfile=Config.MessageResourceBundle;
			}

			//Portabality to load with and without .properties file extendsion
			if(propertyfile.endsWith(".properties")){
				propertyfile=propertyfile.substring(0, propertyfile.indexOf(".properties"));
			}
			
			Locale locale = new Locale("en", "US");
			bundle = ResourceBundle.getBundle(propertyfile, locale);
		} catch (Exception exception) {
			String errorMessage = exception.getMessage();
			logger.log(Level.SEVERE, errorMessage);
			// Throw Runtime error (Unchecked Exception)
			throw new BookingInitilizationError(errorMessage, exception);

		}
		return bundle;
	}

}
